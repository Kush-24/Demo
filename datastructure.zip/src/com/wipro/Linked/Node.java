package com.wipro.Linked;

public class Node {
	public int data;
	public Node next;
}
