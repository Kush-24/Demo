package com.wipro.tree;

public class BinaryTree {
	Node root;
	
	public BinaryTree() {
		root =null;
	}
	
	public BinaryTree(int key) {
		root=new Node(key);
	}

	public void show()
	{
		Node n=root;
		while(n!=null)
		{
						
		}
	}
	
	
}
