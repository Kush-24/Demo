package com.wipro.tree;

public class Node {
		Node left,right;
		int key;
		
		public Node(int item) 
	    { 
	        key = item; 
	        left = right = null; 
	    } 
}
