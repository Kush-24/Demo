package com.kush.springbootrest.service;

import org.springframework.stereotype.Component;

@Component
public class LoginService {

	public boolean validateCredential(String name,String pass) {
		return name.equals("kushagra") && pass.equals("dummy");
	}
}
