package com.kush.springbootrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kush.springbootrest.entities.Employee;
import com.kush.springbootrest.service.EmployeeService;

@RestController
public class MyController {
	
	@Autowired
	EmployeeService empService;
	
	@GetMapping("/")
	public String blankApi() {
		return "Welcome in my controller";
	}
	
	// for getting all employees details from virtual Database.
	@GetMapping("/employees")
	public List<Employee> getEmployees(){
		return empService.getAllEmployee();
	}
	
	// for getting particular Employee with employee id.
	@GetMapping("/employee/{empId}")
	public Employee getEmployee(@PathVariable int empId) {
		return empService.getEmployee(empId);
	}
	
	@PostMapping("/employee")
	public Employee saveEmployee(@RequestBody Employee emp) {
		empService.addEmployee(emp);
		return emp;
	}
	
	@PutMapping("/employee/{empId}")
	public Employee updateEmployee(@PathVariable int empId, @RequestBody Employee emp) {
		 empService.updateEmployee(empId,emp);
		return emp;
		
	}
	
	@GetMapping("/employeerole/{empId}")
	public String getEmployeeRole(@PathVariable int empId) {
		return empService.getEmployeeRole(empId);
	}
	@GetMapping("/employeelead/{empId}")
	public String getEmployeeLead(@PathVariable int empId) {
		return empService.getEmployeeLead(empId);
	}
	
	
}
