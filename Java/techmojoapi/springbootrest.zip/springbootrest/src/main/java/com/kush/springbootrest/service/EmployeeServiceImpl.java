package com.kush.springbootrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kush.springbootrest.dao.EmployeeDatabase;
import com.kush.springbootrest.entities.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	public List<Employee> list;
	
	@Autowired
	EmployeeService employeeService;
	
	public EmployeeServiceImpl() {
		list=EmployeeDatabase.getEmpData();
	}

	@Override
	public List<Employee> getAllEmployee() {
		return list;
	}

	@Override
	public boolean addEmployee(Employee emp) {
		if(emp == null || !(emp instanceof Employee))
		return false;
		
		list.add(emp);
		return true;
	}

	@Override
	public Employee getEmployee(int empId) {
		Employee ans=new Employee(0, "", "", "", null);
		for(Employee emp:list) {
			if(emp.getEmpId()==empId) {
				ans=emp;
				break;
			}
		}
		return ans;
	}

	@Override
	public Employee updateEmployee(int empId, Employee employee) {
		// remove the object from db list.
		Employee emp=employeeService.getEmployee(empId);
		list.remove(emp);
		
		// add new object in the list.
		employeeService.addEmployee(employee);
		
		// return updated employee
	return employee;
	}

	@Override
	public String getEmployeeRole(int empId) {
		Employee emp=employeeService.getEmployee(empId);
		return emp.getRole();
	}

	@Override
	public String getEmployeeLead(int empId) {
		Employee emp=employeeService.getEmployee(empId);
		return emp.getTeamlead();
	}

}
