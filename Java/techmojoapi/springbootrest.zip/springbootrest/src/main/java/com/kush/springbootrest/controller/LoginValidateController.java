package com.kush.springbootrest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kush.springbootrest.service.LoginService;

@Controller 
public class LoginValidateController {
	
    @Autowired
	LoginService service;
   
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String showLoginPage() {
		return "login-page";
	}
	
	@RequestMapping(value="/login" , method=RequestMethod.POST)
	public String showWelcomePage(@RequestParam String name,@RequestParam String password,ModelMap mm) {
		boolean isValid=service.validateCredential(name, password);
	
	// if name & pass is not correct keep on LoginPage.
		if(!isValid) {
			mm.put("errorMessage","Invalid credentials ");
			return "loginwithname";
		}
		mm.addAttribute("name", name); //mm.put() alternative
 		return "welcome"; // redirect to welcome page.
	}
}
