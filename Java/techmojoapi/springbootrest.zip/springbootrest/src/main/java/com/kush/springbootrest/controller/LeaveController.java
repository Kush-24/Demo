package com.kush.springbootrest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.kush.springbootrest.entities.Leave;
import com.kush.springbootrest.service.EmployeeLeaveService;

@RestController
public class LeaveController {
	
	@Autowired
	EmployeeLeaveService employeeLeave;

	@GetMapping("/leave/{empId}")
	public Leave getLeave(@PathVariable int empId) {
		return employeeLeave.getLeaveDetail(empId);
	}
	
}
