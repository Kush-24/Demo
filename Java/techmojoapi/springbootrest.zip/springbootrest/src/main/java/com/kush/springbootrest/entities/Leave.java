package com.kush.springbootrest.entities;

public class Leave {
	private float totalSickLeaves;
	private float totalAnnualLeaves;
	private float totalPaidLeave;
	private float sickLeaveTaken;
	private float annualLeaveTaken;
	private float paidLeaveTaken;
	
	public Leave(float totalSickLeaves, float totalAnnualLeaves, float totalPaidLeave, float sickLeaveTaken,
			float annualLeaveTaken, float paidLeaveTaken) {
		super();
		this.totalSickLeaves = totalSickLeaves;
		this.totalAnnualLeaves = totalAnnualLeaves;
		this.totalPaidLeave = totalPaidLeave;
		this.sickLeaveTaken = sickLeaveTaken;
		this.annualLeaveTaken = annualLeaveTaken;
		this.paidLeaveTaken = paidLeaveTaken;
	}
	
	public float getTotalSickLeaves() {
		return totalSickLeaves;
	}
	public void setTotalSickLeaves(float totalSickLeaves) {
		this.totalSickLeaves = totalSickLeaves;
	}
	public float getTotalAnnualLeaves() {
		return totalAnnualLeaves;
	}
	public void setTotalAnnualLeaves(float totalAnnualLeaves) {
		this.totalAnnualLeaves = totalAnnualLeaves;
	}
	public float getTotalPaidLeave() {
		return totalPaidLeave;
	}
	public void setTotalPaidLeave(float totalPaidLeave) {
		this.totalPaidLeave = totalPaidLeave;
	}
	public float getSickLeaveTaken() {
		return sickLeaveTaken;
	}
	public void setSickLeaveTaken(float sickLeaveTaken) {
		this.sickLeaveTaken = sickLeaveTaken;
	}
	public float getAnnualLeaveTaken() {
		return annualLeaveTaken;
	}
	public void setAnnualLeaveTaken(float annualLeaveTaken) {
		this.annualLeaveTaken = annualLeaveTaken;
	}
	public float getPaidLeaveTaken() {
		return paidLeaveTaken;
	}
	public void setPaidLeaveTaken(float paidLeaveTaken) {
		this.paidLeaveTaken = paidLeaveTaken;
	}
	
	
	
}
