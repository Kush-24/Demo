package com.kush.springbootrest.entities;

public class Employee {
	
	private int empId;
	private String name;
	private static String companyName;
	private String role;
	private String teamlead;
	private Leave leave;
	
	public Employee(int empId, String name, String role, String teamlead, Leave leave) {
		super();
		this.empId = empId;
		this.name = name;
		this.role = role;
		this.teamlead = teamlead;
		this.leave = leave;
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static String getCompanyName() {
		return companyName;
	}
	public static void setCompanyName(String companyName) {
		Employee.companyName = companyName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getTeamlead() {
		return teamlead;
	}
	public void setTeamlead(String teamlead) {
		this.teamlead = teamlead;
	}
	public Leave getLeave() {
		return leave;
	}
	public void setLeave(Leave leave) {
		this.leave = leave;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", role=" + role + ", teamlead=" + teamlead + ", leave="
				+ leave + "]";
	}
}
