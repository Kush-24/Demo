package com.kush.springbootrest.service;

import java.util.List;

import com.kush.springbootrest.entities.Employee;

public interface EmployeeService {

	public List<Employee> getAllEmployee();
	
	public boolean addEmployee(Employee emp);
	
	public Employee getEmployee(int empId);

	public Employee updateEmployee(int empId, Employee emp);

	public String getEmployeeRole(int empId);
	
	public String getEmployeeLead(int empId);
}
