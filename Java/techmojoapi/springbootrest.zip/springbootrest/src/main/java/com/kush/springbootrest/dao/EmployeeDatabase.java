package com.kush.springbootrest.dao;

import java.util.ArrayList;
import java.util.List;

import com.kush.springbootrest.entities.Employee;
import com.kush.springbootrest.entities.Leave;

public class EmployeeDatabase {
	
	public static List<Employee> getEmpData(){
		List<Employee> list=new ArrayList<>();
		Leave leave=EmployeeDatabase.initialLeavesData();
		
		list.add(new Employee(16,"Kushagra Yadav","java developer","sachin", leave));
		list.add(new Employee(42,"Rahul singh","c++ developer","sachin", leave));
		list.add(new Employee(345,"Rajat rathore","phython developer","sachin", leave));
		list.add(new Employee(654,"Raghuveer sing jaat","big data developer","Kushagra", leave));
		list.add(new Employee(12,"Maveer Gurjar","Senior java developer","Ram Singh", leave));
		
		return list;
	}

	private static Leave initialLeavesData() {
		return new Leave(5,10,20,0,0,0);
	}
	
}
