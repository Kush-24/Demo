package com.kush.springbootrest.service;

import com.kush.springbootrest.entities.Leave;

public interface EmployeeLeaveService {
	// return leave detail of employee with respect to id
	public Leave getLeaveDetail(int empId);
	
	/*
	 * Similarly we can a lot of functionality inside Leave Management:
	 * getCacelledLeaveByEmployee() - cancelled leaves by employees after taken
	 * getFutureLeaveByEmployee() - already approved leave of employee in future
	 * getOverdueLeaveByEmployee()- list containing a summary of leave taken per month
	 * getCurrentMonthLeaveByEmployee() - return current month leaves detail
	 * getAllLeaveUnderManger()- return all employees on leave under particular manager.
	 */
}
