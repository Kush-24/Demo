package com.kush.springbootrest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kush.springbootrest.entities.Employee;
import com.kush.springbootrest.entities.Leave;

@Service
public class EmployeeLeaveServiceImpl implements EmployeeLeaveService{

	@Autowired
	EmployeeService employeeService;
	
	@Override
	public Leave getLeaveDetail(int empId) {
		Employee emp=employeeService.getEmployee(empId);
		return emp.getLeave();
	}

}
